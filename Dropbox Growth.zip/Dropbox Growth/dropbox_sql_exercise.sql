--(1) Please write a query that outputs a table containing the email of every user's first referral

	SELECT User_Id
	     , Referral_Email
	FROM (SELECT User_Id
    	 	   , Referral_Email
    	       , RANK() OVER (PARTITION BY User_Id ORDER BY Ts) AS Referral_Order
          FROM User_Referrals
         ) A
    WHERE Referral_Order = 1
    ;

--(2) Please write a query that outputs a table containing the email of every user's second referral
	SELECT User_Id
	     , Referral_Email
	FROM (SELECT User_Id
    	 	   , Referral_Email
    	       , RANK() OVER (PARTITION BY User_Id ORDER BY Ts) AS Referral_Order
          FROM User_Referrals
         ) A
    WHERE Referral_Order = 2
    ;

--(3) Please write a query that outputs a table containing the true percent of the video watched for each user:
	
	SELECT User_Id
		   # Convert String to Int and Get Min Value
	     , MIN(SUBSTRING(Event_Name FROM BEG_SUBSTRING FOR (END_SUBSTRING - BEG_SUBSTRING))::INT) AS Pct
	FROM (SELECT User_Id
	     	   , Event_Name
	     	   # Parse the video playback string (leftside)
	     	   , POSITION('y' in 'video_play_20_pct') + 2 AS BEG_SUBSTRING
	     	   # Parse the video playback string (righside)
	     	   , POSITION('_pct' in 'video_play_20_pct') AS END_SUBSTRING
		  FROM (SELECT User_Id
	     	   		 , Event_Name
	     	   		 # Get the event name that follows.
	     	   		 , LEAD(Event_Name) AS (PARTITION BY User_Id ORDER BY Ts) AS Next_Event_Name
		  		FROM Web_Events
		  		# Only concerned with events on the /video page.
		  		WHERE Url = '/video'
		 		) A
		  # Only conerned with video play events and the following event is not a video playback event
 		  WHERE Next_Event_Name NOT LIKE 'video_play%pct'
 		  AND Event_Name LIKE 'video_play%pct'
 		) B
	GROUP BY 1
 	;



