-- QUERY 1: 
-- Drop (If Exists) and Create Actual_Daily_Report Table
-- So as not to lose any information, we will save all fields (initially) as VARCHAR types.
DROP TABLE IF EXISTS Actual_Daily_Report;
CREATE TABLE Actual_Daily_Report (
	Account_Number VARCHAR,
	MRR VARCHAR,
	MRR_Type VARCHAR
)
;

-- QUERY 2: 
-- Drop (If Exists) and Create Migrated_Table
-- So as not to lose any information, we will save all fields (initially) as VARCHAR types.
DROP TABLE IF EXISTS Migrated_Table;
CREATE TABLE Migrated_Table (
	Account_Number VARCHAR,
	Unknown_MRR VARCHAR,
	Return_MRR VARCHAR,
	Churn_MRR VARCHAR,
	Cont_MRR VARCHAR,
	New_MRR VARCHAR,
	Exp_MRR VARCHAR
)
;

-- QUERY 3: 
-- Load the "actual_daily_report_data.csv" file (this was created by simply saving the .xlsx file as a .csv file) in to the Actual_Daily_Report table created in QUERY 2.
\COPY Actual_Daily_Report FROM '/Users/jteruya/Desktop/SQL Data Challenge/Actual_daily_report_data.csv' DELIMITER ',' CSV HEADER;

-- QUERY 4: 
-- Load the "Migrated_daily_report_data.csv" file in to the Migrated_Table table created in QUERY 2.
\COPY Migrated_Table FROM '/Users/jteruya/Desktop/SQL Data Challenge/Migrated_daily_report_data.csv' DELIMITER ',' CSV HEADER;
