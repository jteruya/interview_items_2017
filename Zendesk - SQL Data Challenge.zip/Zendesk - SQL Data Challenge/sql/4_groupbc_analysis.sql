-- QUERY 18
-- Take a look at the accounts only in the finance file (Group B).  
-- Since we established earlier in QUERY 12 that the amount difference is only present in the unknown column I will look at difference for this amount only.
SELECT Account_Number
     , ACT_Unknown_MRR 
FROM Combine_Reports     
WHERE ACTOnlyFlag = 1
;

-- QUERY 18
-- Taking a quick look it doesn't look like all 15 accounts have a non-zero unknown MRR value.  All 15 accounts are listed below:
/*
 5639776-ZP
 5624158-ZP
 7040089-ZP
 7032836-ZP
 7034495-ZP
 7035808-ZP
 7090896-ZP
 7031119-ZP
 7031566-ZP
 5628948-ZP
 617733-ZP
 7092056-ZP
 5612056-ZP
 5666076-ZP
 5670535-ZP
 */



-- QUERY 19
-- Take a look at the accounts only in the migrated file (Group C).
-- Since we established earlier in QUERY 12 that the amount difference is only present in the unknown column I will look at difference for this amount only.
SELECT Account_Number
     , ACT_Unknown_MRR 
     , MIG_Unknown_MRR 
FROM Combine_Reports     
WHERE MIGOnlyFlag = 1
;

-- QUERY 19 SQL RESULT:
-- Taking a quick look there seems to be a very small number of records that ahave a non-zero unknown mrr value.


-- QUERY 20
-- Get account counts
SELECT COUNT(*) AS AccountCnt
     , COUNT(CASE WHEN MIG_Unknown_MRR > 0 THEN 1 ELSE NULL END) AS UnknownNonZeroCnt
     , COUNT(CASE WHEN MIG_Unknown_MRR = 0 THEN 1 ELSE NULL END) AS UnknownZeroCnt
FROM Combine_Reports     
WHERE MIGOnlyFlag = 1
;
-- QUERY 20 SQL RESULT
	-- AccountCnt: 80,171
		-- AccountNonZeroCnt: 16
		-- AccountZeroCnt: 80,155
-- Clearly, there are two further buckets in GROUP C... 
	-- (1) the 16 accounts that contribute to the unknown MRR value discrepancy and
	-- (2) the 80,155 accounts that contribute nothing to the amount.  they have zero mrr amounts for all mrr types.  This group
			-- is likely because the Product was acquired and because of that all associated accounts from the finance persepective will only be included if there
			-- there is some activity associated with the product.  However, the migrated file includes all accounts regardless of associated activity and therefore
			-- a large number of accounts with non non-zero mrr category.


-- QUERY 21
-- Pull the 16 accounts from GROUP C that have non-zero unknown MRR values.
SELECT Account_Number
     , ACT_Unknown_MRR 
     , MIG_Unknown_MRR 
FROM Combine_Reports     
WHERE MIGOnlyFlag = 1
AND MIG_Unknown_MRR > 0
;

-- QUERY 21 RESULT
-- Looking at the account number these are missing the "-ZP" (assuming that all account numbers need this) thus these did not join correctly.  
-- The list of the 16 accounts that are affected are listed below:
/*
5612056
5624158
5628948
5639776
5666076
5670535
5978239
617733
7031119
7031566
7032836
7034495
7035808
7040089
7090896
7092056
*/
-- If we look specifically at account number (5978239) we can also see that this lines up with the missing mrr unknown value for account 5978239-ZP from GROUP A (QUERY 17) 
-- We should be confident that we need to add the "-ZP" string to the account number for these instances.



