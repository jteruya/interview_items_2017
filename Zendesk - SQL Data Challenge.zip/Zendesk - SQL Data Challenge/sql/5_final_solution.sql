-- QUERY 22
-- Transform the aggregated migration data from QUERY 5 using the rules learned from the analysis.
	-- SQL Change 1: Add "ZP" to accounts for ids where it is only integers and it does not start 'ZD'
	-- SQL Change 2: If Unknown_MRR or Return_MRR is non-zero, the other MRR values should be zero.
	-- SQL Change 3: After corrections from 1 and 2, re-aggregate.
Add corrections that are seen from the analysis and compare.
DROP TABLE IF EXISTS Migrated_Agg_Table_Corr;
CREATE TABLE Migrated_Agg_Table_Corr AS
SELECT Account_Number
     , ROUND(SUM(Unknown_MRR),2) AS Unknown_MRR
     , ROUND(SUM(Return_MRR),2) AS Return_MRR
     , ROUND(SUM(Churn_MRR),2) AS Churn_MRR
     , ROUND(SUM(Cont_MRR),2)AS Cont_MRR
     , ROUND(SUM(New_MRR),2) AS New_MRR
     , ROUND(SUM(Exp_MRR),2) AS Exp_MRR
FROM (SELECT CASE WHEN Account_Number ~ 'Z' THEN Account_Number ELSE Account_Number || '-ZP' END AS Account_Number
            , Unknown_MRR
            , Return_MRR
            , CASE WHEN Unknown_MRR > 0 OR Return_MRR > 0 THEN 0 ELSE Churn_MRR END AS Churn_MRR
            , CASE WHEN Unknown_MRR > 0 OR Return_MRR > 0 THEN 0 ELSE Cont_MRR END AS Cont_MRR
            , CASE WHEN Unknown_MRR > 0 OR Return_MRR > 0 THEN 0 ELSE New_MRR END AS New_MRR
            , CASE WHEN Unknown_MRR > 0 OR Return_MRR > 0 THEN 0 ELSE Exp_MRR END AS Exp_MRR
      FROM Migrated_Agg_Table
     ) M
GROUP BY 1
;

-- QUERY 23
-- Check Fixes against Actual File from Finance as we did before in QUERY 8.
-- Take the aggs from QUERY 22 and QUERY 7 and do a FULL OUTER JOIN to get consolidate all account numbers and values from both files.
DROP TABLE IF EXISTS Combine_Reports_Corr;
CREATE TABLE Combine_Reports_Corr AS
SELECT COALESCE(ACT.Account_Number, MIG.Account_Number) AS Account_Number
     , ACT.Unknown_MRR AS ACT_Unknown_MRR 
     , ACT.Return_MRR AS ACT_Return_MRR
     , ACT.Churn_MRR AS ACT_Churn_MRR
     , ACT.Cont_MRR AS ACT_Cont_MRR
     , ACT.New_MRR AS ACT_New_MRR
     , ACT.Exp_MRR AS ACT_Exp_MRR
     , MIG.Unknown_MRR AS MIG_Unknown_MRR 
     , MIG.Return_MRR AS MIG_Return_MRR
     , MIG.Churn_MRR AS MIG_Churn_MRR
     , MIG.Cont_MRR AS MIG_Cont_MRR
     , MIG.New_MRR AS MIG_New_MRR
     , MIG.Exp_MRR AS MIG_Exp_MRR
     , CASE WHEN ACT.Unknown_MRR IS NOT NULL AND MIG.Unknown_MRR IS NOT NULL THEN 1 ELSE 0 END AS BothFlag
     , CASE WHEN ACT.Unknown_MRR IS NOT NULL AND MIG.Unknown_MRR IS NULL THEN 1 ELSE 0 END AS ACTOnlyFlag
     , CASE WHEN ACT.Unknown_MRR IS NULL AND MIG.Unknown_MRR IS NOT NULL THEN 1 ELSE 0 END AS MIGOnlyFlag
FROM Actual_Daily_Report_Agg ACT
FULL OUTER JOIN Migrated_Agg_Table_Corr MIG
ON ACT.Account_Number = MIG.Account_Number
;

-- QUERY 24:
-- Get Account Count Stats and re-bucket accounts based on the following (this is the same process as QUERY 9):
	-- Group A: Account in both reports.
	-- Group B: Account in Finance (Actual) report only.
	-- Group C: Account in Migrated report only.
SELECT COUNT(*) AS AccountCnt
     , COUNT(CASE WHEN BothFlag = 1 THEN 1 ELSE NULL END) AS BothReportCnt
     , COUNT(CASE WHEN ACTOnlyFlag = 1 THEN 1 ELSE NULL END) AS ActOnlyCnt
     , COUNT(CASE WHEN MIGOnlyFlag = 1 THEN 1 ELSE NULL END) AS MigOnlyCnt
FROM Combine_Reports_Corr
;
-- QUERY 24 SQL RESULT
	-- AccountCnt: 84,822
		-- BothReportCnt: 4,665 (Group A)
		-- ActOnlyCnt: 1 (Group B)
		-- MigOnlyCnt: 80,156 (Group C)

-- QUERY 25
-- Summary of the amount difference across all accounts in the combined table from QUERY 23
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports_Corr
;

-- QUERY 25 SQL RESULT:
	-- Unknown MRR Difference Amount: 0.01
	-- Return MRR Difference Amount: 0.01
	-- Churn MRR Difference Amount: 0.00
	-- Contraction MRR Difference Amount: 0.00
	-- New MRR Difference Amount: 0.00
	-- Expansion MRR Difference Amount: 0.02
-- The amounts reconcile across all accounts and groups.  We need to check a little deeper.

-- QUERY 26
-- Summary of the amount difference across all accounts from GROUP A in the combined table from QUERY 23
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports_Corr
WHERE BothFlag = 1
;
-- QUERY 26 SQL RESULT:
	-- Unknown MRR Difference Amount: 0.01
	-- Return MRR Difference Amount: 0.01
	-- Churn MRR Difference Amount: 0.00
	-- Contraction MRR Difference Amount: 0.00
	-- New MRR Difference Amount: 0.00
	-- Expansion MRR Difference Amount: 0.02
-- The amounts reconcile across all accounts in GROUP A.  

-- QUERY 27
-- Summary of the amount difference across all accounts from GROUP B in the combined table from QUERY 23
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports_Corr
WHERE ACTOnlyFlag = 1
;
-- QUERY 27 SQL RESULT:
	-- Unknown MRR Difference Amount: 0
	-- Return MRR Difference Amount: 0
	-- Churn MRR Difference Amount: 0
	-- Contraction MRR Difference Amount: 0
	-- New MRR Difference Amount: 121.65
	-- Expansion MRR Difference Amount: 0
-- The amounts don't reconcile for the new MRR difference in GROUP B.


-- QUERY 28
-- Summary of the amount difference across all accounts from GROUP C in the combined table from QUERY 23
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports_Corr
WHERE MIGOnlyFlag = 1
;

-- QUERY 28 SQL RESULTS:
	-- Unknown MRR Difference Amount: 0
	-- Return MRR Difference Amount: 0
	-- Churn MRR Difference Amount: 0
	-- Contraction MRR Difference Amount: 0
	-- New MRR Difference Amount: -121.65
	-- Expansion MRR Difference Amount: 0
-- The amounts don't reconcile for the new MRR difference in GROUP C.  This is by the same amount as the discrepancy for GROUP B seen in QUERY 27.  If we pull the accounts
-- associated with this we see that it is one account in each file and for the migrated it is 682562-ZP and for the actual file it is 682562.  Based on this, we can see
-- that this discrepancy occurs even after our corrections because there is an error in the account number in the actual file and the migrated file has the correct 
-- acount form.

-- Finally, I've included a summary of the problems accounts in the excel file "problem_accounts.xlsx" and possible solutions.  
-- With these fixes, assuming the data problems are similar to other quarters, the migrated report can be used instead of the one from finance.
-- Please note that I did not include the accounts that are in the migrated file which did not have an associated activity with the product as there are over 80,000+.

