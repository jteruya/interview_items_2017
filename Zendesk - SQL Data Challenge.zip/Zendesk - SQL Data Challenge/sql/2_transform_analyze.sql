
-- QUERY 5:
-- Convert MRR values and aggregate the amounts in Migrated_Table (created in QUERY 2) by account number and save to Migrated_Agg_Table.  
-- We will make the assumption based on what I see in the excel file:
	-- (1) The MRR field must have a value made up of numbers.  If not (e.g."#VALUE"), then the value is assumed to be zero.
DROP TABLE IF EXISTS Migrated_Agg_Table;
CREATE TABLE Migrated_Agg_Table AS
SELECT Account_Number
     , SUM(CASE WHEN Unknown_MRR ~ '[0-9]' THEN Unknown_MRR::NUMERIC ELSE 0 END) AS Unknown_MRR
     , SUM(CASE WHEN Return_MRR ~ '[0-9]' THEN Return_MRR::NUMERIC ELSE 0 END) AS Return_MRR
     , SUM(CASE WHEN Churn_MRR ~ '[0-9]' THEN Churn_MRR::NUMERIC ELSE 0 END) AS Churn_MRR
     , SUM(CASE WHEN Cont_MRR ~ '[0-9]' THEN Cont_MRR::NUMERIC ELSE 0 END) AS Cont_MRR
     , SUM(CASE WHEN New_MRR ~ '[0-9]' THEN New_MRR::NUMERIC ELSE 0 END) AS New_MRR
     , SUM(CASE WHEN Exp_MRR ~ '[0-9]' THEN Exp_MRR::NUMERIC ELSE 0 END) AS Exp_MRR
FROM Migrated_Table
GROUP BY 1
;

-- QUERY 6:
-- Sanity check to ensure the data has been loaded and converted correctly.  Compare the aggregates calculated in QUERY 5 to the excel file "Migrated_daily_report_data.csv".
SELECT SUM(Unknown_MRR) AS Unknown_MRR
     , SUM(Return_MRR) AS Return_MRR
     , SUM(Churn_MRR) AS Churn_MRR
     , SUM(Cont_MRR) AS Cont_MRR
     , SUM(New_MRR) AS New_MRR
     , SUM(Exp_MRR) AS Exp_MRR
FROM Migrated_Agg_Table;
;
-- QUERY 6 SQL RESULT:
    -- SQL Result:
		-- Unknown_MRR: 1,804.68864
		-- Return_MRR: 8,026.107264
		-- Churn_MRR: -16,103.097216
		-- Cont_MRR: -4,971.984768
		-- New_MRR: 13,259.808000
		-- Exp_MRR: 18,906.818688
	-- Excel Count/Sum Functon Result:
		-- Unknown_MRR: 1,804.68864
		-- Return_MRR: 8,026.107264
		-- Churn_MRR: -16,103.09722
		-- Cont_MRR: -4,971.984768
		-- New_MRR: 13,259.808
		-- Exp_MRR: 18,906.81869

-- The total MRR values check out compared with the amounts calculated in Excel.


-- QUERY 7
-- Convert MRR values and aggregate the MRR amounts in Actual_Daily_Report (created in QUERY 1) by account number and MRR typpe and save to Actual_Daily_Report_Agg. 
DROP TABLE IF EXISTS Actual_Daily_Report_Agg;
CREATE TABLE Actual_Daily_Report_Agg AS
SELECT Account_Number
     , SUM(CASE WHEN MRR_Type = 'Unknown' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS Unknown_MRR
     , SUM(CASE WHEN MRR_Type = 'Return' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS Return_MRR
     , SUM(CASE WHEN MRR_Type = 'Churned' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS Churn_MRR
	 , SUM(CASE WHEN MRR_Type = 'Contraction' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS Cont_MRR
	 , SUM(CASE WHEN MRR_Type = 'New' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS New_MRR
	 , SUM(CASE WHEN MRR_Type = 'Expansion' THEN REPLACE(MRR, ',', '')::NUMERIC ELSE 0 END) AS Exp_MRR
FROM Actual_Daily_Report
GROUP BY 1
;

-- QUERY 8:
-- Sanity check to ensure the data has been loaded and converted correctly.  Compare the aggregates calculated in QUERY 7 to the excel file "actual_daily_report_data.csv".
SELECT SUM(Unknown_MRR) AS Unknown_MRR
     , SUM(Return_MRR) AS Return_MRR
     , SUM(Churn_MRR) AS Churn_MRR
     , SUM(Cont_MRR) AS Cont_MRR
     , SUM(New_MRR) AS New_MRR
     , SUM(Exp_MRR) AS Exp_MRR
FROM Actual_Daily_Report_Agg;
;
-- QUERY 6 SQL RESULT:
    -- SQL Result:
		-- Unknown_MRR: 1,804.68
		-- Return_MRR: 8,026.42
		-- Churn_MRR: -16,103.96
		-- Cont_MRR: -4,972.39
		-- New_MRR: 13,223.80
		-- Exp_MRR: 18,565.51
	-- Excel Count/Sum Functon Result:
		-- Unknown_MRR: 1,804.68
		-- Return_MRR: 8,026.42
		-- Churn_MRR: -16,103.96
		-- Cont_MRR: -4,972.39
		-- New_MRR: 13,223.80
		-- Exp_MRR: 18,565.51

-- The total MRR values check out compared with the amounts calculated in Excel.

-- QUERY 8:
-- Take the aggs from QUERY 5 and QUERY 7 and do a FULL OUTER JOIN to get consolidate all account numbers and values from both files.
DROP TABLE IF EXISTS Combine_Reports;
CREATE TABLE Combine_Reports AS
SELECT COALESCE(ACT.Account_Number, MIG.Account_Number) AS Account_Number
     , ACT.Unknown_MRR AS ACT_Unknown_MRR 
     , ACT.Return_MRR AS ACT_Return_MRR
     , ACT.Churn_MRR AS ACT_Churn_MRR
     , ACT.Cont_MRR AS ACT_Cont_MRR
     , ACT.New_MRR AS ACT_New_MRR
     , ACT.Exp_MRR AS ACT_Exp_MRR
     , MIG.Unknown_MRR AS MIG_Unknown_MRR 
     , MIG.Return_MRR AS MIG_Return_MRR
     , MIG.Churn_MRR AS MIG_Churn_MRR
     , MIG.Cont_MRR AS MIG_Cont_MRR
     , MIG.New_MRR AS MIG_New_MRR
     , MIG.Exp_MRR AS MIG_Exp_MRR
     , CASE WHEN ACT.Unknown_MRR IS NOT NULL AND MIG.Unknown_MRR IS NOT NULL THEN 1 ELSE 0 END AS BothFlag
     , CASE WHEN ACT.Unknown_MRR IS NOT NULL AND MIG.Unknown_MRR IS NULL THEN 1 ELSE 0 END AS ACTOnlyFlag
     , CASE WHEN ACT.Unknown_MRR IS NULL AND MIG.Unknown_MRR IS NOT NULL THEN 1 ELSE 0 END AS MIGOnlyFlag
FROM Actual_Daily_Report_Agg ACT
FULL OUTER JOIN Migrated_Agg_Table MIG
ON ACT.Account_Number = MIG.Account_Number
;

-- QUERY 9:
-- Get Account Count Stats and bucket accounts based on the following:
	-- Group A: Account in both reports.
	-- Group B: Account in Finance (Actual) report only.
	-- Group C: Account in Migrated report only.
SELECT COUNT(*) AS AccountCnt
     , COUNT(CASE WHEN BothFlag = 1 THEN 1 ELSE NULL END) AS BothReportCnt
     , COUNT(CASE WHEN ACTOnlyFlag = 1 THEN 1 ELSE NULL END) AS ActOnlyCnt
     , COUNT(CASE WHEN MIGOnlyFlag = 1 THEN 1 ELSE NULL END) AS MigOnlyCnt
FROM Combine_Reports
;

-- QUERY 9 SQL Results:
	-- AccountCnt: 84,837
	-- BothReportCnt: 4,651 (Group A)
	-- ActOnlyCnt: 15 (Group B)
	-- MigOnlyCnt: 80,171 (Group C)

-- QUERY 10:
-- Summary of the amount difference across all accounts in the combined table from QUERY 9
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports
;

-- QUERY 10 SQL RESULTS:
	-- DiffUnknownAmt: -0.00864
	-- DiffReturnAmt: 0.312736
	-- DiffChurnAmt: -0.862784
	-- DiffContAmt: -0.405232
	-- DiffNewAmt: -36.0080000
	-- DiffExpAmt: -341.308688

-- When we find the root causes, this should be zero (or close to it) for all MRR amounts across all accounts.


-- QUERY 11:
-- Summary of the amount difference across all accounts from GROUP A in the combined table from QUERY 9
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports
WHERE BothFlag = 1
;

-- QUERY 11 SQL RESULTS:
	-- DiffUnknownAmt: 437.19
	-- DiffReturnAmt: 0.312736
	-- DiffChurnAmt: -0.862784
	-- DiffContAmt: -0.405232
	-- DiffNewAmt: -36.0080000
	-- DiffExpAmt: -341.308688

-- When we find the root causes, this should be zero (or close to it) for all MRR amounts across all accounts.	

-- QUERY 12:
-- Summary of the amount difference across all accounts from GROUP B in the combined table from QUERY 9
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports
WHERE ACTOnlyFlag = 1
;
-- QUERY 12 SQL RESULTS:
	-- DiffUnknownAmt: 1,367.49
	-- DiffReturnAmt: 0
	-- DiffChurnAmt: 0
	-- DiffContAmt: 0
	-- DiffNewAmt: 0
	-- DiffExpAmt: 0

-- When we find the root causes, this should be zero (or close to it) for all MRR amounts across all accounts.

-- QUERY 12:
-- Summary of the amount difference across all accounts from GROUP C in the combined table from QUERY 9
SELECT SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Unknown_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Unknown_MRR ELSE 0 END) AS DiffUnknownAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Return_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Return_MRR ELSE 0 END) AS DiffReturnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Churn_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Churn_MRR ELSE 0 END) AS DiffChurnAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Cont_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Cont_MRR ELSE 0 END) AS DiffContAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_New_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_New_MRR ELSE 0 END) AS DiffNewAmt
     , SUM(CASE WHEN BothFlag =1 OR ACTOnlyFlag = 1 THEN ACT_Exp_MRR ELSE 0 END) - SUM(CASE WHEN BothFlag =1 OR MIGOnlyFlag = 1 THEN MIG_Exp_MRR ELSE 0 END) AS DiffExpAmt
FROM Combine_Reports
WHERE MIGOnlyFlag = 1
;

-- QUERY 12 SQL RESULTS:
	-- DiffUnknownAmt: -1,804.68864
	-- DiffReturnAmt: 0
	-- DiffChurnAmt: 0
	-- DiffContAmt: 0
	-- DiffNewAmt: 0
	-- DiffExpAmt: 0

-- When we find the root causes, this should be zero (or close to it) for all MRR amounts across all accounts.


