-- QUERY 13:
-- Group A (Accounts in both files) only.  This includes amount differences for each account to see where there are discrepancies for each account.
DROP TABLE IF EXISTS GroupA_Diff;
CREATE TABLE GroupA_Diff AS
SELECT Account_Number
     , @ (ACT_Unknown_MRR - MIG_Unknown_MRR) <= 0.01 AS UnknownDiffFlag
     , @ (ACT_Return_MRR - MIG_Return_MRR) <= 0.01 AS ReturnDiffFlag
     , @ (ACT_Churn_MRR - MIG_Churn_MRR) <= 0.01 AS ChurnDiffFlag
     , @ (ACT_Cont_MRR - MIG_Cont_MRR) <= 0.01 AS ContDiffFlag
     , @ (ACT_New_MRR - MIG_New_MRR) <= 0.01 AS NewDiffFlag
     , @ (ACT_Exp_MRR - MIG_Exp_MRR) <= 0.01 AS ExpDiffFlag
     , (@ (ACT_Unknown_MRR - MIG_Unknown_MRR) <= 0.01) AND (@ (ACT_Return_MRR - MIG_Return_MRR) <= 0.01) AND (@ (ACT_Churn_MRR - MIG_Churn_MRR) <= 0.01) AND (@ (ACT_Cont_MRR - MIG_Cont_MRR) <= 0.01) AND (@ (ACT_New_MRR - MIG_New_MRR) <= 0.01) AND (@ (ACT_Exp_MRR - MIG_Exp_MRR) <= 0.01) AS GoodFlag
FROM Combine_Reports
WHERE BothFlag = 1
;

-- QUERY 14:
-- Count the number of accounts with a total MRR value discrepancy between the two reports in each category from the accounts in GROUP A.
SELECT COUNT(*) AS AccountCnt
     , COUNT(CASE WHEN GoodFlag = FALSE THEN 1 ELSE NULL END) AS DiffAccountCnt
     , COUNT(CASE WHEN UnknownDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffUnknownCnt
     , COUNT(CASE WHEN ReturnDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffReturnCnt
     , COUNT(CASE WHEN ChurnDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffChurnCnt
     , COUNT(CASE WHEN ContDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffContCnt
     , COUNT(CASE WHEN NewDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffNewCnt
     , COUNT(CASE WHEN ExpDiffFlag = FALSE THEN 1 ELSE NULL END) AS DiffExpCnt
FROM GroupA_Diff
;

-- QUERY 14 SQL RESULTS:
  -- AccountCnt: 4,651
    -- DiffAccountCnt: 18
      -- DiffUnknownCnt: 1
      -- DiffReturnCnt: 0
      -- DiffChurnCnt: 0
      -- DiffContCnt: 0
      -- DiffNewCnt: 5
      -- DiffExpCnt: 12

-- From this, we will focus on the 18 accounts with discrpencies in GROUP A and the three MRR categories affected (Unknown, New and Exp)


-- QUERY 15:
-- Look at the New MRR discrpencies for the 5 GROUP A accounts.
SELECT A.*
FROM Combine_Reports A
JOIN GroupA_Diff B
ON A.Account_Number = B.Account_Number
WHERE B.GoodFlag = FALSE AND NewDiffFlag = FALSE
;

-- QUERY 15 SQL RESULTS:
-- There are 5 accounts where in the migration file they are being counted new and return when in the actual it is just return.  
-- Since these accounts have a non-zero MRR return value they should have a zero New MRR value according 
-- to the rules laid out in the background information.
-- The 5 accounts affected are (5012285-ZP, 5067586-ZP, 5164995-ZP, 5489479-ZP, 5988456-ZP)


-- QUERY 16:
-- Look at the Exp discrpencies for the 12 GROUP A accounts.
SELECT A.*
FROM Combine_Reports A
JOIN GroupA_Diff B
ON A.Account_Number = B.Account_Number
WHERE B.GoodFlag = FALSE AND ExpDiffFlag = FALSE
;

-- QUERY 16 SQL RESULTS:
-- There are 12 accounts where in the migration file they are being counted exp and return when in the actual it is just return.  
-- Since these accounts have a non-zero MRR return value they should have a zero Exp MRR value according 
-- to the rules laid out in the background information.
-- The 12 accounts affected are (138175-ZP, 205855-ZP, 332940-ZP, 369008-ZP, 448349-ZP, 449089-ZP, 5022848-ZP, 5205093-ZP, 5957435-ZP, 670608-ZP, 7093598-ZP, 894749-ZP)

-- QUERY 17:
-- Look at the Unknown discripencies for the 1 GROUP A account.
SELECT A.*
FROM Combine_Reports A
JOIN GroupA_Diff B
ON A.Account_Number = B.Account_Number
WHERE B.GoodFlag = FALSE AND UnknownDiffFlag = FALSE
; 

-- QUERY 17 SQL RESULTS:
-- There is 1 account (5978239-ZP) where the unknown value is populated on the actual file but not in the migration file.  
-- In addition, since this has a non-zero Unknown value, the churn value should be zero.
-- Not sure why the unknown value is only populated from one source but going to move on to the analysis of Group B and C and that might shed more light.

