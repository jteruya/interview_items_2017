-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- SCHEMA SETUP SQL
-- All of the commands below were excuted using psql (PostgreSQL 9.3).

-- Create MyCustomerTable Structure
CREATE TABLE MyCustomerTable (
  CustomerID INT,
  FirstName VARCHAR,
  MiddleName VARCHAR,
  LastName VARCHAR,
  Phone BIGINT
)
;

-- Create MyCustomerTransactionTable Structure
CREATE TABLE MyCustomerTransactionTable (
  CustomerID INT,
  Date DATE,
  Action VARCHAR,
  Amount INT
)
;

-- Populate MyCustomerTable Table
INSERT INTO MyCustomerTable (CustomerID, FirstName, MiddleName, LastName, Phone) VALUES
  (111,'Bob','L','Smith',4151567832),
  (123,'Jeremy','Jay','Bronze',5109657651),
  (222,'Rebecca',NULL,'Jones',2549813657),
  (456,'Jennifer',NULL,'Lee',4159998456)
;

-- Populate MyCustomerTransactionTable Table
INSERT INTO MyCustomerTransactionTable (CustomerID, Date, Action, Amount) VALUES 
  (111,'2015-02-02','Deposit',100),
  (111,'2015-01-27','Withdrawl',25),
  (111,'2014-12-12','Inquiry',NULL),
  (222,'2015-04-05','Deposit',500),
  (222,'2014-12-12','Withdrawl',200),
  (456,'2015-03-01','Deposit',175),
  (456,'2015-02-21','Deposit',25)
;


-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 1: 
-- Write a query that would display all the phone #'s from the 'MyCustomerTable' table that are in the 415 area code.

-- QUESTION 1 SQL:

SELECT Phone
FROM MyCustomerTable
WHERE Phone/10000000 = 415
;

-- QUESTION 1 SQL RESULT:
/*
   phone    
------------
 4151567832
 4159998456
(2 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 2:
-- Write a query that would display how many of each Action there are in the table 'MyCustomerTransactionTable', with results sorted by Action 

-- QUESTION 2 SQL:

SELECT Action
     , COUNT(*) AS ActionCnt
FROM MyCustomerTransactionTable
GROUP BY Action
ORDER BY Action
;

-- QUESTION 2 SQL RESULT: 
/*
  action   | actioncnt 
-----------+-----------
 Deposit   |         4
 Inquiry   |         1
 Withdrawl |         2
(3 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 3:
-- Write a query that would retrieve how many unique customers have made Deposits 

-- QUESTION 3 SQL:

SELECT COUNT(DISTINCT CustomerID) AS DepositCustomerCnt
FROM MyCustomerTransactionTable
WHERE Action = 'Deposit'
;

-- QUESTION 3 SQL RESULT: 
/*
 depositcustomercnt 
--------------------
                  3
(1 row)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 4:
-- Write a query that displays all the customer information for customers who do not have at least one 'Withdrawl' transaction.

-- QUESTION 4 SQL:

SELECT CUST.*
FROM MyCustomerTable CUST
LEFT JOIN (SELECT DISTINCT CustomerID
           FROM MyCustomerTransactionTable
           WHERE Action = 'Withdrawl') TRANS
ON CUST.CustomerID = TRANS.CustomerID
WHERE TRANS.CustomerID IS NULL
;

-- QUESTION 4 SQL RESULT:
/*
 customerid | firstname | middlename | lastname |   phone    
------------+-----------+------------+----------+------------
        123 | Jeremy    | Jay        | Bronze   | 5109657651
        456 | Jennifer  |            | Lee      | 4159998456
(2 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 5:
-- Write a query that would retrieve the CustomerID, full customer name, and how many transactions (any type) that particular customer has performed

-- QUESTION 5 SQL:

SELECT CUST.CustomerID
     , CUST.FirstName
     , CUST.MiddleName
     , CUST.LastName
     , COUNT(CASE WHEN TRANS.CustomerID IS NOT NULL THEN 1 ELSE NULL END) AS TransCnt
FROM MyCustomerTable CUST
LEFT JOIN MyCustomerTransactionTable TRANS
ON CUST.CustomerID = TRANS.CustomerID
GROUP BY CUST.CustomerID, CUST.FirstName, CUST.MiddleName, CUST.LastName
;

-- QUESTION 5 SQL RESULT:
/*
 customerid | firstname | middlename | lastname | transcnt 
------------+-----------+------------+----------+----------
        222 | Rebecca   |            | Jones    |        2
        123 | Jeremy    | Jay        | Bronze   |        0
        111 | Bob       | L          | Smith    |        3
        456 | Jennifer  |            | Lee      |        2
(4 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 6:
-- Write a query that for each customerID would display the total 'Amount' for that customer, where Deposit Actions are added to the total and Withdrawls are substracted from total

-- QUESTION 6 SQL:

SELECT CUST.CustomerID
     , SUM(CASE WHEN TRANS.Action = 'Deposit' THEN TRANS.Amount ELSE 0 END) - SUM(CASE WHEN TRANS.Action = 'Withdrawl' THEN TRANS.Amount ELSE 0 END) AS Amount
FROM MyCustomerTable CUST
LEFT JOIN MyCustomerTransactionTable TRANS
ON CUST.CustomerID = TRANS.CustomerID
GROUP BY CUST.CustomerID
;

-- QUESTION 6 SQL RESULT:
/*
 customerid | amount 
------------+--------
        222 |    300
        123 |      0
        111 |     75
        456 |    200
(4 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 7:
-- Write a query that shows the # of each of Deposit/Withdrawl/Inquiry Actions for each CustomerID - one row per customer

-- QUESTION 7 SQL:

SELECT CUST.CustomerID
     , COUNT(CASE WHEN TRANS.Action = 'Deposit' THEN 1 ELSE NULL END) AS DepositCnt
     , COUNT(CASE WHEN TRANS.Action = 'Withdrawl' THEN 1 ELSE NULL END) AS WithdrawlCnt
     , COUNT(CASE WHEN TRANS.Action = 'Inquiry' THEN 1 ELSE NULL END) AS InquiryCnt
FROM MyCustomerTable CUST
LEFT JOIN MyCustomerTransactionTable TRANS
ON CUST.CustomerID = TRANS.CustomerID
GROUP BY CUST.CustomerID
;

-- QUESTION 7 SQL RESULT:
/*
 customerid | depositcnt | withdrawlcnt | inquirycnt 
------------+------------+--------------+------------
        222 |          1 |            1 |          0
        123 |          0 |            0 |          0
        111 |          1 |            1 |          1
        456 |          2 |            0 |          0
(4 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 8:
-- Write a query that displays the CustomerID's of the customers who do not have at least 2 deposits

-- QUESTION 8 SQL:

SELECT CUST.CustomerID
FROM MyCustomerTable CUST
LEFT JOIN MyCustomerTransactionTable TRANS
ON CUST.CustomerID = TRANS.CustomerID
GROUP BY CUST.CustomerID
HAVING COUNT(CASE WHEN TRANS.Action = 'Deposit' THEN 1 ELSE NULL END) < 2
;

-- QUESTION 8 SQL RESULT:
/*
 customerid 
------------
        222
        123
        111
(3 rows)
*/

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- QUESTION 9:
-- Write a query that shows the CustomerID, date of their first action, and what kind of action it was

-- QUESTION 9 SQL:

SELECT DISTINCT CUST.CustomerID
     , MIN(TRANS.Date) OVER (PARTITION BY CUST.CustomerID) AS FirstDate
     , FIRST_VALUE(TRANS.Action) OVER (PARTITION BY CUST.CustomerID ORDER BY TRANS.Date) AS ActionType
FROM MyCustomerTable CUST
LEFT JOIN MyCustomerTransactionTable TRANS
ON CUST.CustomerID = TRANS.CustomerID
;

-- QUESTION 9 SQL RESULT:
/*
customerid | firstdate  | actiontype 
------------+------------+------------
        123 |            | 
        222 | 2014-12-12 | Withdrawl
        456 | 2015-02-21 | Deposit
        111 | 2014-12-12 | Inquiry
(4 rows)
*/



